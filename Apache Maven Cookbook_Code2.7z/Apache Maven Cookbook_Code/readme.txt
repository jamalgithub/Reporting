
Each of the code sample is a separate Maven project and can be build independently.

It would be good to run the code as you read the specific recipe of the cookbook. 
