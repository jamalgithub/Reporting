package com.packt.cookbook;

/**
 * Hello world!
 *
 */
public class Two 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
